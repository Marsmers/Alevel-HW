import React from 'react';
import './App.css';
import Carousel from './components/carousel/carousel';

function App() {
    return (
        <Carousel/>
    )
}

export default App;

