import '../HomePage/style.css';


export default function HomePage() {





  return (
    <div className="cons">
      <div className="coco">
        <div className="home">
            <div className="sliderHome">
          </div>
        </div>
      </div>
    </div>
  )
}
